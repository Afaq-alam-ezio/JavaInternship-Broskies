package com.Task8ByBroSkiesHub.Task8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Task8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
