package com.Task8ByBroSkiesHub.Task8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Task8Application {

	public static void main(String[] args) {
		SpringApplication.run(Task8Application.class, args);
	}

}
